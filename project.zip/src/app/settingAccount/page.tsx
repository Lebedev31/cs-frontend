import SettingAccount from "@/Components/ProfileDropDown/SettingAccount/SettingAccount";

export default function SettingPage() {
  return <SettingAccount />;
}
