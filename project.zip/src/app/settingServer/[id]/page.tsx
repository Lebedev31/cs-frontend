import WrapperSettingServer from "@/Components/AddServer/WrapperSettingServer";

export default function SettingServerPage() {
  return <WrapperSettingServer />;
}
