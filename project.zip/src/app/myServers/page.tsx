export const dynamic = "force-dynamic";
import MyServers from "@/Components/ProfileDropDown/MyServers/MyServers";

export default function MyServersPage() {
  return <MyServers />;
}
