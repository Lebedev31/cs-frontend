import ForgotPassword from "@/Components/Registration/ForgotPassword/ForgotPassword";

export default function ForgotPage() {
  return <ForgotPassword />;
}
