export const dynamic = "force-dynamic";
import FinHistory from "@/Components/ProfileDropDown/FinHistory/FinHistory";

export default function FinHistoryPage() {
  return <FinHistory />;
}
