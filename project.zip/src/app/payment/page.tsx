import PaymentForm from "@/Components/ProfileDropDown/PaymentForm/PaymentForm";

export default function PaymentPage() {
  return <PaymentForm />;
}
