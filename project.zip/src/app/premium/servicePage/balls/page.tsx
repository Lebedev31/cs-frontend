import Balls from "@/Components/Premium/Service/Balls/Balls";

export default function BallsPage() {
  return <Balls />;
}
