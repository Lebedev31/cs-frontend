import Top from "@/Components/Premium/Service/Top/Top";

export default function TopPage() {
  return <Top />;
}
