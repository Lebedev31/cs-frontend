import Color from "@/Components/Premium/Service/Color/Color";

export default function ColorPage() {
  return <Color />;
}
