import Vip from "@/Components/Premium/Service/Vip/Vip";

export default function ServicePage() {
  return <Vip />;
}
